from django.apps import AppConfig


class MainthemeConfig(AppConfig):
    name = 'maintheme'
